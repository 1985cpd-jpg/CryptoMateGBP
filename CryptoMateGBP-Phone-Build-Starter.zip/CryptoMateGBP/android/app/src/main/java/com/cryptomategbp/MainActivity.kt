package com.cryptomategbp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.CurrencyBitcoin
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.IOException

private val Navy = Color(0xFF0B1020)
private val Panel = Color(0xFF151D32)
private val Muted = Color(0xFFA8B1C7)
private val Accent = Color(0xFF8D91FF)
private val Green = Color(0xFF47D7AC)

data class Coin(val id: String, val name: String, val price: String, val change: String = "—")

class MarketRepository {
    private val client = OkHttpClient()
    // Android Emulator -> host computer. Use HTTPS backend URL for deployed builds.
    private val baseUrl = "http://10.0.2.2:8000"

    suspend fun price(product: String): String = withContext(Dispatchers.IO) {
        val request = Request.Builder().url("$baseUrl/market/$product").build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) throw IOException("Market service returned ${response.code}")
            JSONObject(response.body?.string() ?: "{}").optString("price", "Unavailable")
        }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CryptoMateApp() }
    }
}

@Composable
fun CryptoMateApp() {
    val repo = remember { MarketRepository() }
    var page by remember { mutableStateOf("Market") }
    var selected by remember { mutableStateOf("BTC") }
    var prices by remember { mutableStateOf(mapOf<String, String>()) }
    var error by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        val products = listOf("BTC-GBP", "ETH-GBP", "SOL-GBP", "XRP-GBP", "ADA-GBP")
        products.forEach { product ->
            try {
                val price = repo.price(product)
                prices = prices + (product.substringBefore("-") to price)
            } catch (e: Exception) {
                error = "Can't reach market service. Start the backend to load prices."
            }
        }
    }

    val coins = listOf(
        Coin("BTC", "Bitcoin", prices["BTC"] ?: "Loading…", "+ —"),
        Coin("ETH", "Ethereum", prices["ETH"] ?: "Loading…"),
        Coin("SOL", "Solana", prices["SOL"] ?: "Loading…"),
        Coin("XRP", "XRP", prices["XRP"] ?: "Loading…"),
        Coin("ADA", "Cardano", prices["ADA"] ?: "Loading…")
    )

    MaterialTheme(colorScheme = darkColorScheme(
        background = Navy, surface = Panel, primary = Accent,
        onBackground = Color.White, onSurface = Color.White,
        secondary = Green
    )) {
        Scaffold(
            containerColor = Navy,
            bottomBar = {
                NavigationBar(containerColor = Panel) {
                    NavigationBarItem(selected = page == "Market", onClick = { page = "Market" },
                        icon = { Icon(Icons.Default.CurrencyBitcoin, null) }, label = { Text("Market") })
                    NavigationBarItem(selected = page == "Trade", onClick = { page = "Trade" },
                        icon = { Icon(Icons.Default.SwapHoriz, null) }, label = { Text("Trade") })
                    NavigationBarItem(selected = page == "Portfolio", onClick = { page = "Portfolio" },
                        icon = { Icon(Icons.Default.AccountBalanceWallet, null) }, label = { Text("Portfolio") })
                    NavigationBarItem(selected = page == "Watchlist", onClick = { page = "Watchlist" },
                        icon = { Icon(Icons.Default.Star, null) }, label = { Text("Watchlist") })
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(42.dp).background(Accent, RoundedCornerShape(12.dp)),
                        contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.CurrencyBitcoin, null, tint = Color.White)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("CryptoMate GBP", fontSize = 21.sp, fontWeight = FontWeight.Bold)
                        Text("Coinbase · Personal trading", color = Muted, fontSize = 12.sp)
                    }
                    Surface(color = Color(0xFF59451B), shape = RoundedCornerShape(50)) {
                        Text("PREVIEW", Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            color = Color(0xFFFFD479), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
                Spacer(Modifier.height(18.dp))
                when (page) {
                    "Market" -> {
                        Surface(color = Panel, shape = RoundedCornerShape(18.dp)) {
                            Column(Modifier.fillMaxWidth().padding(18.dp)) {
                                Text("Portfolio balance", color = Muted)
                                Spacer(Modifier.height(6.dp))
                                Text("£—", fontSize = 32.sp, fontWeight = FontWeight.Bold)
                                Text("Connect your Coinbase account to load real holdings",
                                    color = Muted, fontSize = 12.sp)
                            }
                        }
                        Spacer(Modifier.height(18.dp))
                        Text("Markets", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Text("GBP pairs · Prices from public market endpoint", color = Muted, fontSize = 11.sp)
                        Spacer(Modifier.height(8.dp))
                        if (error != null) {
                            Text(error!!, color = Color(0xFFFFD479), fontSize = 12.sp)
                        }
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(coins) { coin ->
                                Surface(color = Panel, shape = RoundedCornerShape(14.dp),
                                    modifier = Modifier.fillMaxWidth().clickable {
                                        selected = coin.id; page = "Trade"
                                    }) {
                                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Box(Modifier.size(42.dp).background(Color(0xFF26314A), CircleShape),
                                            contentAlignment = Alignment.Center) {
                                            Text(coin.id.take(1), fontWeight = FontWeight.Bold)
                                        }
                                        Spacer(Modifier.width(12.dp))
                                        Column(Modifier.weight(1f)) {
                                            Text(coin.name, fontWeight = FontWeight.SemiBold)
                                            Text("${coin.id}/GBP", color = Muted, fontSize = 12.sp)
                                        }
                                        Text(coin.price, fontWeight = FontWeight.SemiBold)
                                    }
                                }
                            }
                        }
                    }
                    "Trade" -> TradeScreen(selected = selected, onSelect = { selected = it })
                    "Portfolio" -> InfoScreen("Portfolio", "Real balances are not connected yet. They will be loaded securely through the backend after read-only API access is configured.")
                    else -> InfoScreen("Watchlist", "Watchlist storage and live refresh will be added next.")
                }
            }
        }
    }
}

@Composable
fun TradeScreen(selected: String, onSelect: (String) -> Unit) {
    var side by remember { mutableStateOf("Buy") }
    var amount by remember { mutableStateOf("25.00") }
    var reviewed by remember { mutableStateOf(false) }
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Trade", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text("Preview only — orders are not sent to Coinbase.", color = Color(0xFFFFD479))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Buy", "Sell").forEach { choice ->
                FilterChip(selected = side == choice, onClick = { side = choice; reviewed = false },
                    label = { Text(choice) })
            }
        }
        Text("Coin")
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("BTC", "ETH", "SOL", "XRP", "ADA").forEach { symbol ->
                FilterChip(selected = selected == symbol, onClick = { onSelect(symbol); reviewed = false },
                    label = { Text(symbol) })
            }
        }
        OutlinedTextField(value = amount, onValueChange = { amount = it; reviewed = false },
            label = { Text("Amount in GBP (£)") }, singleLine = true)
        Text("Order type: Market (preview)", color = Muted)
        Button(onClick = { reviewed = true }, enabled = (amount.toDoubleOrNull() ?: 0.0) > 0) {
            Text("Review $side order")
        }
        if (reviewed) {
            Surface(color = Panel, shape = RoundedCornerShape(14.dp)) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Order preview", fontWeight = FontWeight.Bold)
                    Text("$side $selected · £${amount}")
                    Text("No order has been submitted. Fees and execution price are not calculated.",
                        color = Muted, fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
fun InfoScreen(title: String, message: String) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(title, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Surface(color = Panel, shape = RoundedCornerShape(14.dp)) {
            Text(message, Modifier.padding(16.dp), color = Muted)
        }
    }
}
