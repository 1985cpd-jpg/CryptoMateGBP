# CryptoMate GBP — Android starter

This is a **starter project**, not a live trading application yet. The Android app is a Kotlin/Jetpack Compose UI. The included Python backend serves public Coinbase market prices and deliberately blocks private account/trading actions until authenticated Coinbase Advanced Trade API integration and security review are completed.

## Project structure

- `android/` — Android Studio project source (Kotlin + Jetpack Compose)
- `backend/` — FastAPI service for public market data and a fail-closed private-trading placeholder

## 1. Run the backend (public market data only)

Requires Python 3.11+.

```bash
cd backend
python -m venv .venv
# macOS/Linux:
source .venv/bin/activate
# Windows PowerShell:
# .venv\Scripts\Activate.ps1
pip install -r requirements.txt
uvicorn app:app --reload --host 127.0.0.1 --port 8000
```

Open `http://127.0.0.1:8000/health` or `http://127.0.0.1:8000/market/BTC-GBP`.

For Android Emulator, the app uses `10.0.2.2` to reach the development machine. On a physical phone, change `BASE_URL` in `MarketRepository.kt` to your development computer's LAN address. Do not expose this development server to the public internet.

## 2. Open the Android app

Open the `android/` folder in Android Studio. Use a recent stable Android Studio with Android SDK installed, allow Gradle sync, then run the `app` configuration on an emulator or Android phone.

The app currently shows a sample portfolio and a live-market-data connection to the local backend. If the backend is not running, the app shows an error rather than pretending prices are live.

## 3. Secure Coinbase connection — required before real trading

1. Sign in to the official Coinbase Developer Platform: https://www.coinbase.com/developer-platform/products/advanced-trade-api
2. Create a dedicated API key for your own account. Start with **View/read-only permissions** to test account access. Later, use **Trade** only if you intentionally enable order placement. Do not grant transfer/withdrawal permissions.
3. Keep the downloaded private key/secret out of the Android app, Git, screenshots, chat, and logs. Never send credentials to anyone.
4. Store the key in a secrets manager or protected environment variable on a private backend. Restrict network access and allowlist the backend's fixed IP where supported.
5. Use Coinbase's current official Advanced Trade SDK/API authentication instructions. Add account/balance and order endpoints to the backend only after testing with read-only permissions.
6. Before enabling orders, require a fresh order preview, show the estimated total and fees, validate product/amount/available balance on the server, enforce spending limits, use unique client order IDs/idempotency where supported, and reconcile the final order status from Coinbase.
7. Add login, server-side authorization, rate limiting, audit logs that exclude secrets, dependency updates, TLS, monitoring, backups, and a kill switch. Test failures and rejected orders.
8. Review Coinbase terms, availability for your account, and relevant UK requirements before using the app.

**Important:** A mobile app cannot safely hold a Coinbase private API key. Android Keystore can protect local app secrets, but it does not make embedding an exchange API private key in the APK safe. The private key belongs on the server.

## Current limitations

- No private Coinbase account access.
- No real buy/sell orders are submitted.
- No API secrets or keys are included.
- Prices are only live if the backend can reach Coinbase's public endpoint.
- This starter is not audited or production-ready. Do not deposit funds or rely on it for trading.

## 4. Build an APK using only an Android phone (GitHub Actions)

This project includes `.github/workflows/android-apk.yml`. It lets GitHub build a **debug/test APK in the cloud**, so you do not need Android Studio on your phone.

1. In your Android browser, sign in to GitHub and create a **private** repository named `CryptoMateGBP`.
2. Upload the contents of this project ZIP to the repository (upload the files inside the `CryptoMateGBP` folder, including the `.github` folder; do not upload only the ZIP file).
3. Open the repository's **Actions** tab. If GitHub asks, enable workflows.
4. Select **Build CryptoMate GBP APK** → **Run workflow** → **Run workflow**.
5. When the run finishes successfully, open it and download the `CryptoMateGBP-debug-apk` artifact. Extract it on your phone to get `app-debug.apk`.
6. Open the APK to install it if Android permits installation from that browser/files app. Only install APKs built from source you trust.

**Important limitations:** this is only a debug build. The app currently points market requests at `10.0.2.2`, which is for an emulator and will not work on your phone by itself. To use it on a phone, deploy the public-price backend to a trusted HTTPS host and update `baseUrl` in `MarketRepository.kt` to that HTTPS URL, then rerun the workflow. No Coinbase credentials are needed for public prices.

Real account balances, assisted signals, and automated trading are not enabled yet. Do not add API secrets to the repository or APK. When account access is added, start with a Coinbase **View-only** API key stored as a server-side secret; never grant Transfer permission. Live trading and automation must remain disabled until server-side authentication, strict spending limits, order previews, audit logging, a kill switch, and testing are complete.
