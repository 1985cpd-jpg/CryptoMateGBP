from fastapi import FastAPI, HTTPException
import httpx

app = FastAPI(title="CryptoMate GBP API", version="0.1.0")
COINBASE_PUBLIC = "https://api.coinbase.com/v2/prices"

@app.get("/health")
async def health():
    return {"status": "ok", "mode": "public-market-data-only"}

@app.get("/market/{product}")
async def market_price(product: str):
    # Accept only simple GBP product identifiers such as BTC-GBP.
    allowed = {"BTC-GBP", "ETH-GBP", "SOL-GBP", "XRP-GBP", "ADA-GBP"}
    if product not in allowed:
        raise HTTPException(status_code=400, detail="Unsupported product")
    url = f"{COINBASE_PUBLIC}/{product}/spot"
    try:
        async with httpx.AsyncClient(timeout=8.0) as client:
            response = await client.get(url)
            response.raise_for_status()
            data = response.json()["data"]
            return {"product": product, "currency": data["currency"], "price": data["amount"]}
    except (httpx.HTTPError, KeyError, ValueError):
        raise HTTPException(status_code=502, detail="Unable to retrieve market price")

@app.get("/private/account")
async def private_account():
    # Fail closed until official Coinbase Advanced Trade SDK auth is implemented.
    raise HTTPException(
        status_code=501,
        detail="Coinbase account integration is not configured. No credentials are accepted by this endpoint."
    )

@app.post("/private/orders")
async def place_order():
    # Intentionally disabled: prevents accidental real-money orders.
    raise HTTPException(
        status_code=501,
        detail="Live trading is disabled. Add and security-review official Coinbase API integration first."
    )
